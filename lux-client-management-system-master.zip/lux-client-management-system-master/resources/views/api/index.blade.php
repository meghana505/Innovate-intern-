<x-app-layout pagename="API Tokens">
    <div>
        <div class="max-w-3xl">
            @livewire('api.api-token-manager')
        </div>
    </div>
</x-app-layout>
