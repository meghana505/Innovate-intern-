<x-app-layout pagename="Add Client">
    <livewire:clients.create/>
</x-app-layout>
