<x-app-layout pagename="Edit Client">
    <livewire:clients.edit :client="$client"/>
</x-app-layout>
