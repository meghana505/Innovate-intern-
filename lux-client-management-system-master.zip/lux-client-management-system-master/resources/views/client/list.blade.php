<x-app-layout pagename="Clients">
    <livewire:clients.index/>
</x-app-layout>
