<x-app-layout pagename="Dashboard">
    <div class="mx-auto">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            <x-jet-welcome/>
        </div>
    </div>
</x-app-layout>
