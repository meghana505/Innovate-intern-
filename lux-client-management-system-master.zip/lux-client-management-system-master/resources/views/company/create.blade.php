<x-app-layout pagename="Add Company">
    <livewire:companies.create />
</x-app-layout>
