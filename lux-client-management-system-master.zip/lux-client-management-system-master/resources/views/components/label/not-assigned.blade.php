<div class="inline border-2 bg-gray-100 border-gray-400 text-gray-400 text-xs px-1 font-bold">
    <p>Not Assigned</p>
</div>
