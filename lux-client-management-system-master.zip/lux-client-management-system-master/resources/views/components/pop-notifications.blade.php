<div
    class="flex flex-col-reverse items-end justify-start h-auto w-72 pb-3 absolute bottom-0 right-0 mr-4 z-20"
>
    <x-alert.success />
</div>
