<div class="flex justify-center items-center">
    <svg class="block h-7 w-auto" viewBox="0 0 16 16" fill="{{$fillColor}}" xmlns="http://www.w3.org/2000/svg">
        <rect width="4" height="5" x="1" y="10" rx="1"></rect>
        <rect width="4" height="9" x="6" y="6" rx="1"></rect>
        <rect width="4" height="14" x="11" y="1" rx="1"></rect>
    </svg>

    <div class="flex items-center ml-2" style="color: {{$fillColor}}">
        <h2 class="font-bold text-3xl">Lux</h2>
    </div>

</div>
