<div>
    <x-company.list.index :companies="$companies" :deleting="$deleting" :checked="$checked" :search="$search"/>
</div>
