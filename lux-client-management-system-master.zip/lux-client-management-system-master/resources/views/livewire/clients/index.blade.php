<div>
    <x-client.list.index :clients="$clients" :deleting="$deleting" :checked="$checked" :search="$search"/>
</div>
